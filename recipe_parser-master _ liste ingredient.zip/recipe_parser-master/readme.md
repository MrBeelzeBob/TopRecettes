Used for getting recipes from website, parsing the html and extracting relevant terms to enable searching by specific ingredients

Used purely for educational/demo purposes